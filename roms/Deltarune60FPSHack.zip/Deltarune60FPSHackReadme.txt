DELTARUNE 60FPS HACK | By ShootingStarr

This is a Deltarune mod that allows the game to run at 60FPS, non-sped up, with only minor bugs.

By default, the game normally runs at 30FPS. This mod changes it to 60FPS.



Install instructions (Manual / data.win):

1: (Recommended) Make a backup of your Deltarune data.win (Found in C:/Program Files (x86)/SURVEY_PROGRAM ) before proceeding.

2: Replace data.win in SURVEY_PROGRAM folder with the data.win you downloaded

3: The mod should be active now, enjoy!



Install Instructions (Deltapatcher):

1: (Recommended) Make a backup of your Deltarune data.win (Found in C:/Program Files (x86)/SURVEY_PROGRAM ) before proceeding.

2: Run DeltaPatcher.exe

3: For Original File, navigate to C:/Program Files (x86)/SURVEY_PROGRAM (Or wherever you installed Deltarune) and select data.win

4: For xdelta patch, select Deltarune60FPSHack.xdelta

5: Select Apply Patch and it should patch successfully!

5.5: If you receive an "Access is denied" error, restart from Step 2 but run DeltaPatcher.exe as Administrator!



Known Bugs:

-A few minor animations might be double speed.

-There may be minor graphical glitches when moving around at times. I cannot fix this for the time being, sorry!